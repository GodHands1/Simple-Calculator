package com.example.simplecalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.example.simplecalculator.R; // Ensure your package name is correct

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView display;
    private String currentInput = "";
    private double result = 0.0;
    private String lastOperator = "";
    private boolean isNewCalculation = true; // Flag to indicate if we're starting a new number or operation

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        display = findViewById(R.id.displayTextView);
        display.setText("0");
        setupButtonListeners();
    }
    private void setupButtonListeners() {
        int[] numberButtonIds = {
                R.id.button_0, R.id.button_1, R.id.button_2, R.id.button_3,
                R.id.button_4, R.id.button_5, R.id.button_6, R.id.button_7,
                R.id.button_8, R.id.button_9
        };

        int[] operatorButtonIds = {
                R.id.button_add, R.id.button_subtract, R.id.button_multiply,
                R.id.button_divide, R.id.button_percent
        };

        View.OnClickListener numberListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button b = (Button) v;
                appendNumber(b.getText().toString());
            }
        };

        for (int id : numberButtonIds) {
            findViewById(id).setOnClickListener(numberListener);
        }

        View.OnClickListener operatorListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button b = (Button) v;
                handleOperator(b.getText().toString());
            }
        };

        for (int id : operatorButtonIds) {
            findViewById(id).setOnClickListener(operatorListener);
        }

        findViewById(R.id.button_clear).setOnClickListener(v -> clear());
        findViewById(R.id.button_decimal).setOnClickListener(v -> appendDecimal());
        findViewById(R.id.button_equals).setOnClickListener(v -> calculateResult());
    }

    private void appendNumber(String number) {
        if (currentInput.equals("0") || isNewCalculation) {
            currentInput = number;
        } else {
            currentInput += number;
        }
        isNewCalculation = false;
        display.setText(currentInput);
    }

    private void appendDecimal() {
        if (isNewCalculation) {
            currentInput = "0.";
            isNewCalculation = false;
        } else if (!currentInput.contains(".")) {
            currentInput += ".";
        }
        display.setText(currentInput);
    }

    private void handleOperator(String operator) {
        if (!lastOperator.isEmpty() && !isNewCalculation) {
            calculate();
        }
        else if (isNewCalculation) {
        }
        else {
            try {
                result = Double.parseDouble(currentInput);
            }
            catch (NumberFormatException e) {
                display.setText("Error");
                currentInput = "";
                return;
            }
        }

        lastOperator = operator;
        isNewCalculation = true;
    }
    private void calculateResult() {
        if (lastOperator.isEmpty()) return;

        calculate();
        lastOperator = "";
        currentInput = formatResult(result);
        isNewCalculation = true; //
        display.setText(currentInput);
    }

    private void calculate() {
        if (isNewCalculation) return;

        double secondOperand;
        try {
            secondOperand = Double.parseDouble(currentInput);
        } catch (NumberFormatException e) {
            display.setText("Error");
            return;
        }

        switch (lastOperator) {
            case "+":
                result += secondOperand;
                break;
            case "–":
                result -= secondOperand;
                break;
            case "×":
                result *= secondOperand;
                break;
            case "÷":
                if (secondOperand == 0) {
                    display.setText("Error");
                    result = 0.0;
                    lastOperator = "";
                    currentInput = "";
                    isNewCalculation = true;
                    return;
                }
                result /= secondOperand;
                break;
            case "%":
                result = result * (secondOperand / 100);
                break;
            default:
                break;
        }

        currentInput = formatResult(result);
        display.setText(currentInput);
        isNewCalculation = true;
    }
    private void clear() {
        currentInput = "";
        result = 0.0;
        lastOperator = "";
        isNewCalculation = true;
        display.setText("0");
    }
    private String formatResult(double value) {
        if (value == (long) value) {
            return String.format("%d", (long) value);
        } else {
            return String.format("%.10f", value).replaceAll("0*$", "").replaceAll("\\.$", "");
        }
    }
}
